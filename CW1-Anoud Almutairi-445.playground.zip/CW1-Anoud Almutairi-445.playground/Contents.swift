import UIKit

let name = "Anoud Almutairi"

var hobby1 = "reading"

var hobby2 = "graphic designing"

var age = 15

var height = 153

print ("My name is \(name)" )

let friendname = "Shaha Al Ajeel"

var friendhobby1 = "reading"

var friendhobby2 = "playing video games"

var friendage = 15

var friendheight = 158

age <= friendage

height < friendheight

var agedifference = ( age-friendage)


